#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <sys/time.h>
#include <ctime>

using namespace std;

struct nodo {
  int pid;
  bool pronto = false;
  float tempoStart;
  float tempoExec;
  struct nodo *prox;
};

struct cabeca {
  int qtdElementos;         //quantidade de na fila
  nodo *inicio;          //o primeiro inserido
  nodo *fim;          //o ultimo inserido
};

static int pidCont = 0;
struct timeval inicioTime;

void inserir(cabeca *cabecalho);
void mostrar(cabeca *cabecalho);

int main()
{
  int op = 1;
  cabeca *cabecalho = NULL;

  cabecalho = new cabeca();
  cabecalho->inicio = NULL;
  cabecalho->fim = NULL;
  cabecalho->qtdElementos = 0;

  while (op != 0){
    cout <<"\n\n\n\tQuantidade de dados na fila:" << cabecalho->qtdElementos;
    cout <<"\n\t------------------MENU PRINCIPAL------------------\n\n";      
    cout <<"\t\t\t1 - Inserir na fila\n";
    cout <<"\t\t\t2 - Retirar 1º da fila\n";
    cout <<"\t\t\t3 - Imprimir fila\n";
    cout <<"\t\t\t0 - Sair\n";
    cout <<"\n\t\t";
    cin >> op;

    switch (op){

        case 1:
            cout <<"\n\t--------------------------------------------------\n";
            inserir(cabecalho);
            cout <<"\n\t--------------------------------------------------\n";
            cout <<"\n\t";
        break; 

        case 2:
            cout <<"\n\t--------------------------------------------------\n";
            
            cout <<"\n\t--------------------------------------------------\n";
            cout <<"\n\t";
        break;

        case 3:
            cout <<"\n\t--------------------------------------------------\n";
            mostrar(cabecalho);
            cout <<"\n\t--------------------------------------------------\n";
            cout <<"\n\t";
        break;

      }
  }
  return EXIT_SUCCESS;
}

void inserir(cabeca *cabecalho){

  nodo *novoItem;

  novoItem = new nodo();  

  if (novoItem) {
    novoItem->pid = pidCont;
    pidCont++;
    novoItem->pronto = true;
    novoItem->tempoStart = gettimeofday(&inicioTime, NULL);
    novoItem->tempoExec = (rand()%(30-0+1) + 0) * 1000;

    if (cabecalho->inicio == NULL) {
      novoItem->prox = NULL;
      cabecalho->inicio = novoItem;
    }else {
      novoItem->prox = cabecalho->fim;
    }
    cabecalho->fim = novoItem;
    cabecalho->qtdElementos = (cabecalho->qtdElementos) + 1;
  } 
}


void mostrar(cabeca *cabecalho){
  nodo *pAux;
  int i = cabecalho->qtdElementos;
  int teste = 0;

  if (cabecalho->inicio == NULL) cout <<"\n\t\tLista Vazia\n";
  else {

    pAux = cabecalho->fim;
    cout <<"\t\t------------------------------------------------------\n";
    cout <<"\t\t|   Posicao   |     PID    |    Start   |    Time    |\n";
    cout <<"\t\t------------------------------------------------------\n";

    while (pAux != NULL) {
      teste = 0;

      if(pAux == cabecalho->fim){
        cout << "\t\t|Last " << setw(8) << i <<"|"<< setw(12) <<  pAux->pid <<"|"<< setw(12) <<  pAux->tempoStart<<"|"<< setw(12) <<  pAux->tempoExec<<"|\n";
        teste = 1;
      }
      if(pAux == cabecalho->inicio){
        cout << "\t\t|First" << setw(8) << i <<"|"<< setw(12) <<  pAux->pid <<"|"<< setw(12) <<  pAux->tempoStart<<"|"<< setw(12) <<  pAux->tempoExec<<"|\n";
        teste = 1;
      }else if(teste == 0) {
        cout << "\t\t|" << setw(13) << i <<"|"<< setw(12) <<  pAux->pid<<"|"<< setw(12) <<  pAux->tempoStart<<"|"<< setw(12) <<  pAux->tempoExec<<"|\n";
      }
      
      
      cout <<"\t\t------------------------------------------------------\n";
      
      pAux = pAux->prox;
      i--;
    }

  }
}