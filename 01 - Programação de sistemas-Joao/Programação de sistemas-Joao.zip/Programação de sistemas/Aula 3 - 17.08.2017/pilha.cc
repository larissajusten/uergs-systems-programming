#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include <string>
using std::string;
#include <iomanip>

using namespace std;


struct nodo {
	int pid;
	struct nodo *ant;
};

struct cabeca {
	int qtdElementos;					//quantidade de elementos na pilha
	nodo *baseDaPilha;					//o primeiro inserido
	nodo *topoDaPilha;					//o ultimo inserido
};

static int pidCont = 0;

void push(cabeca *cabecalho);
void pop(cabeca *cabecalho);
void imprimir(cabeca *cabecalho);

int main(){
	cabeca *cabecalho = NULL;
	int op = 1;

	cabecalho = (cabeca*)malloc(sizeof(cabeca));
	cabecalho->baseDaPilha = NULL;
	cabecalho->topoDaPilha = NULL;
	cabecalho->qtdElementos = 0;

	while (op != 0){

     	cout <<"\n\n\n\tQuantidade de dados na pilha:" << cabecalho->qtdElementos;
        cout <<"\n\t------------------MENU PRINCIPAL------------------\n\n";      
        cout <<"\t\t\t1 - Empilhar (push)\n";
        cout <<"\t\t\t2 - Desempilhar (pop)\n";
        cout <<"\t\t\t3 - Imprimir Lista\n";
        cout <<"\t\t\t0 - Sair\n";
        cout <<"\n\t\t";
        cin >> op;

        switch (op){

            case 1:
                cout <<"\n\t--------------------------------------------------\n";
               	push(cabecalho);
                cout <<"\n\t--------------------------------------------------\n";
                cout <<"\n\t";
            break; 

            case 2:
                cout <<"\n\t--------------------------------------------------\n";
               	pop(cabecalho);
                cout <<"\n\t--------------------------------------------------\n";
                cout <<"\n\t";
            break;

            case 3:
                cout <<"\n\t--------------------------------------------------\n";
               	imprimir(cabecalho);
                cout <<"\n\t--------------------------------------------------\n";
                cout <<"\n\t";
            break;

        }
    }
	return 0;
}

void push(cabeca *cabecalho){

	nodo *novoItemNaPilha;

	novoItemNaPilha = (nodo*)malloc(sizeof(nodo));	

	if (novoItemNaPilha) {
		novoItemNaPilha->pid = pidCont;
		pidCont++;
		if (cabecalho->baseDaPilha == NULL) {

			novoItemNaPilha->ant = NULL;
			cabecalho->baseDaPilha = novoItemNaPilha;

		}else novoItemNaPilha->ant = cabecalho->topoDaPilha;

		cabecalho->topoDaPilha = novoItemNaPilha;
		cabecalho->qtdElementos = (cabecalho->qtdElementos) + 1;
	}	
}

void pop(cabeca *cabecalho){

	nodo *pAux;

	

	if(cabecalho->topoDaPilha != NULL){

		pAux = cabecalho->topoDaPilha;

		if(pAux->ant == NULL){
			cabecalho->topoDaPilha = NULL;
			cabecalho->baseDaPilha = NULL;
		}else{
			cabecalho->topoDaPilha = pAux->ant;
		}

		cabecalho->qtdElementos = (cabecalho->qtdElementos) - 1;
		

		free(pAux);
	}else cout <<"\n\t\tNenhum elemento na pilha!\n";
	
}

void imprimir(cabeca *cabecalho){
	nodo *pAux;
	int i = cabecalho->qtdElementos, teste = 0;

	if (cabecalho->baseDaPilha == NULL) cout <<"\n\t\tLista Vazia\n";
 	else {

		pAux = cabecalho->topoDaPilha;
		cout <<"\t\t----------------------------\n";
		cout <<"\t\t|   Posicao   |     PID    |\n";
		cout <<"\t\t----------------------------\n";

		while (pAux != NULL) {
			teste = 0;

			if(pAux == cabecalho->topoDaPilha){
				cout << "\t\t|TOPO:" << setw(8) << i <<"|"<< setw(12) <<  pAux->pid <<"|\n";
				teste = 1;
			}
			if(pAux == cabecalho->baseDaPilha){
				cout << "\t\t|BASE:" << setw(8) << i <<"|"<< setw(12) <<  pAux->pid <<"|\n";
				teste = 1;
			}
			else if(teste == 0) cout << "\t\t|" << setw(13) << i <<"|"<< setw(12) <<  pAux->pid <<"|\n";
			
			cout <<"\t\t----------------------------\n";
			
			pAux = pAux->ant;
			i--;
		}

	}
}