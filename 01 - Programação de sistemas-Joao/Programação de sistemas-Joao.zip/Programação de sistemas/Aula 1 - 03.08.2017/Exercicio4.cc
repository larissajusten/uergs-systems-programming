#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include <string>
using std::string;

struct funcionario{
	int  id;
	string nome;
	int sexo; //0: feminino, 1: masculino
	int departamento; //0: vendas, 1: compras
	float salario;
};

funcionario f[5];
static int id = 0;

void ler()
{
	for (int i = 0; i < 5; ++i)
	{	
		id++;
		f[i].id = id;
		cout << "Usuario " << id << endl;
		cout << "\tNome: ";
  		cin >> f[i].nome;
  		cout << "\tSexo: ";
  		cin >> f[i].sexo;
  		cout << "\tDepartamento: ";
  		cin >> f[i].departamento;
  		cout << "\tSalario: ";
  		cin >> f[i].salario;
	}
}

void imprimir()
{
	for (int i = 0; i < 5; ++i)
	{	
		cout << "ID: " << f[i].id << endl;
		cout << "Nome: " << f[i].nome << endl;
		if (f[i].sexo == 0){
			cout << "Sexo: feminino"<< endl;
		}else{
			cout << "Sexo: masculino"<< endl;
		}
		if (f[i].departamento == 0){
			cout << "Departamento: Vendas"<< endl;
		}else{
			cout << "Departamento: compras"<< endl;
		}
		cout << "Salario: " << f[i].salario << endl << endl;
	}
}

void imprimirQtdMulherVendas()
{
	int qtd = 0;
	for (int i = 0; i < 5; ++i)
	{	
		if (f[i].sexo == 0 && f[i].departamento == 0){
			qtd++;
		}
	}
	cout << endl << "Quantidade de mulheres no setor de vendas: " << qtd << endl << endl;
}

void mediaSalarioHomensVendas()
{
	int salTotal = 0;
	int qtd = 0;
	for (int i = 0; i < 5; ++i)
	{	
		if (f[i].sexo == 1 && f[i].departamento == 0){
			salTotal += f[i].salario;
			qtd++;
		}
	}
	cout << endl << "Media salarial de homens no setor de vendas: " << salTotal/qtd << endl << endl;
}

int main()
{	
	int fim = 0;
	cout << "----------INICIO FUNÇÃO LER----------" <<endl;
	ler();
	cout << "----------FIM FUNÇÃO LER----------" <<endl;
	cout << "----------INICIO FUNÇÃO imprimirQtdMulherVendas----------" <<endl;
	imprimirQtdMulherVendas();
	cout << "----------FIM FUNÇÃO imprimirQtdMulherVendas----------" <<endl;
	cout << "----------INICIO FUNÇÃO mediaSalarioHomensVendas----------" <<endl;
	mediaSalarioHomensVendas();
	cout << "----------FIM FUNÇÃO mediaSalarioHomensVendas----------" <<endl;
	imprimir();

  	cout << "\n\nDigite uma letra para continuar..." << endl;
	fflush(stdin);	//limpa o buffer do teclado
	cin >> fim;
	return 0;
}