#include <stdio.h>

static float m[3][3];

void ler()
{
	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 3; ++j)
		{
			printf("\nInsira um valor em m[%d][%d]: ",i,j);
			scanf("%f", &m[i][j]);
		}
	}
}

void maiorLinha()
{
	int qtdLinha = 0;
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			if(m[i][j] > 20){
				qtdLinha++;
			}
			if(j==2 && qtdLinha > 0 ){
				printf("\nLinha %d possui %d elementos com valor maior que 20!",i,qtdLinha );
				qtdLinha = 0;
			}
		}
	}
}

void removerNeg()
{
	for (int i = 0; i < 3; ++i){
		if(m[1][i] < 0){
			m[1][i] = 5;
		}
	}
}

void imprimir()
{
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			printf("\nm[%d][%d] : %f!",i,j,m[i][j] );
		}
	}
}

int main()
{	
	ler();
	maiorLinha();
	removerNeg();
	imprimir();

	printf("\n\nDigite uma tecla para continuar..."); //printf indica ao final do programa
	__fpurge(stdin);	//limpa o buffer do teclado
	getchar();	//continua o programa se inserir alguma coisa
	exit(1); //encerra o programa e indica se houve algum erro
	return 0;
}