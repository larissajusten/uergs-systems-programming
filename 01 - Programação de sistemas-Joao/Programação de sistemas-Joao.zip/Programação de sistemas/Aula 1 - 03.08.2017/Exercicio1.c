#include <stdio.h>

static int tamanhoV = 10;
static int V[10];

void ler()
{
	for (int i = 0; i < tamanhoV; ++i){
		printf("\nInsira um valor: ");
		scanf("%d", &V[i]);
	}
}

int qtdDivTres()
{	
	int quantidadeDivisores = 0;
	for (int i = 0; i < tamanhoV; ++i){
		if((V[i] % 3) == 0){
			quantidadeDivisores++;
		}
	}

	return quantidadeDivisores;
}

float mediaAritmetica()
{
	float total = 0;
	for (int i = 0; i < tamanhoV; ++i){
		total += V[i];
	}

	return total/tamanhoV;
}

int main()
{	
	ler();

	printf("Quantidade de elementos divisives por 3: %d\n", qtdDivTres());

	printf("Media aritmetica dos elementos do vetor: %f\n", mediaAritmetica());

	printf("\n\nDigite uma tecla para continuar..."); //printf indica ao final do programa
	__fpurge(stdin);	//limpa o buffer do teclado
	getchar();	//continua o programa se inserir alguma coisa
	exit(1); //encerra o programa e indica se houve algum erro
	return 0;
}