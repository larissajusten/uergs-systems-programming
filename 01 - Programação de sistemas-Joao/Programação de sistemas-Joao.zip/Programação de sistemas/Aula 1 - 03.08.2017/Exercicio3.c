#include <stdio.h>

static float m[3][3];
static float v[3] = {};

void ler()
{
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			printf("\nInsira um valor em m[%d][%d]: ",i,j);
			scanf("%f", &m[i][j]);
		}
	}
}

void somaCol(){
	for (int i = 0; i < 3; ++i){
		for (int j = 1; j < 3; ++j){
			v[i] += m[i][j];
		}
	}
}

void imprimir()
{
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			printf("\nm[%d][%d] : %f!",i,j,m[i][j] );
		}
	}

	for (int i = 0; i < 3; ++i){
		printf("\nv[%d] : %f!",i,v[i]);
	}
}

int main()
{	
	ler();
	somaCol();
	imprimir();

	printf("\n\nDigite uma tecla para continuar..."); //printf indica ao final do programa
	__fpurge(stdin);	//limpa o buffer do teclado
	getchar();	//continua o programa se inserir alguma coisa
	exit(1); //encerra o programa e indica se houve algum erro
	return 0;
}