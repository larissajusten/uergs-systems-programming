#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include <string>
using std::string;


#include <fstream>

using namespace std;

#define QTD_OBJETO 100

struct obj{
	int  id;
	string nome;
	int idade;
};

obj objeto[QTD_OBJETO] = {};
obj objetoAux[QTD_OBJETO] = {};

FILE *arqlista;
ofstream arq;

static int id = 0;
static int posProx = 0;
static int posBusc = -1;

void inicializarTabela();
void cadastrar();
void listar();
void ordenacao();
void ordByName();
void ordByIdade();
void busca();
void search(string tipo);
void loadObjAuxWithObj();
void loadObjWithAux();
void remove();
void salvaTabela();

int main()
{	
	int op = 1;

	inicializarTabela();

	while (op != 0){
     
        cout << "\n\n\n\t\t--MENU PRINCIPAL--" <<endl;       
        cout << "\t1 - Cadastrar elemento na tabela " <<endl;
        cout << "\t2 - Listar elementos da tabela" <<endl;
        cout << "\t3 - Ordernar tabela" <<endl;
        cout << "\t4 - Buscar na tabela" <<endl;
        cout << "\t5 - Remover elemento" <<endl;
        cout << "\t0 - Sair" <<endl;
        cout << "\n\t\tSua opção: ";
        cin >> op;

        switch (op){

            case 1:
                cout << "\n\t--------------------------------------------------\n" <<endl;
                cadastrar();
                cout << "\n\t--------------------------------------------------\n" <<endl;
                cout << "\n\t" <<endl;
            break;

            case 2:
                cout << "\n\t--------------------------------------------------\n" <<endl;
                listar();
                cout << "\n\t--------------------------------------------------\n" <<endl;
                cout << "\n\t" <<endl;
            break;

            case 3:
                cout << "\n\t--------------------------------------------------\n" <<endl;
                ordenacao();
                cout << "\n\t--------------------------------------------------\n" <<endl;
                cout << "\n\t" <<endl;
            break;

            case 4:
                cout << "\n\t--------------------------------------------------\n" <<endl;
                busca();
                cout << "\n\t--------------------------------------------------\n" <<endl;
                cout << "\n\t" <<endl;
            break;

            case 5:
                cout << "\n\t--------------------------------------------------\n" <<endl;
                remove();
                cout << "\n\t--------------------------------------------------\n" <<endl;
                cout << "\n\t" <<endl;
            break;

            default:
            	cout << "\n\t--------------------------------------------------" <<endl;
            	cout << "\n\t\tOpção inválida!" << endl;
                cout << "\n\t--------------------------------------------------\n" <<endl;
                cout << "\n\t" <<endl;
            break;
        }
    }
    salvaTabela();
	return 0;
}

void inicializarTabela()
{
	int j =0;
	int i = 0;
  	char nome[50],temp;
	if((arqlista = fopen("lista-de-pessoas.txt", "rt")) == NULL){
		cout<<"FALHA NA ABERTURA DO ARQUIVO\n";
	}

	cout<<"\n\n\t\tCarregando arquivo....\n";

	while (!feof(arqlista)) {
		fscanf(arqlista,"%c",&temp); // le o primeiro caracter
		i=0; // reseta o contador para nao dar erro se houver mais de um nome
		while (temp != '|') { // enquanto ele nao achar o | ele roda

			nome[i++] = temp; //vai acrescentando caracter a caracter na variavel nome ate encontrar o |

			fscanf(arqlista,"%c",&temp); // le um caracter

			if (feof(arqlista)) {
				break; // para evitar de ficar lendo se o final do arquivo foi atingido
			}

		}

		if (feof(arqlista)){
			break; // para evitar de ficar lendo se o final do arquivo foi atingido
		}
		nome[i] = '\0'; // adiciona \0 para sinalizar o final da string
		objeto[j].nome = nome;
		fscanf(arqlista,"%d",&objeto[j].id); // le a a idade apos ler todo o
		fscanf(arqlista,"%d",&objeto[j].idade); // le a a idade apos ler todo o
		j++;
		posProx++;
		id++;

	}

	fclose(arqlista);
}

void cadastrar()
{
	id++;
	cout << "\n\tId: " << id;
	objeto[posProx].id = id;
	cout << "\n\tNome: ";
    cin >> objeto[posProx].nome;
    cout << "\tIdade: ";
    cin >> objeto[posProx].idade;
    posProx++;
}

void listar()
{
	int elementos = 0;

	for (int i = 0; i < posProx; ++i){
		if((objeto[i].id > 0) and (objeto[i].nome != "") and (objeto[i].idade > 0)){
			cout << "\n\tId: " << objeto[i].id;
			cout << "\n\tNome: " << objeto[i].nome;
			cout << "\n\tIdade: " << objeto[i].idade << endl << endl;
			elementos++;
		}
	}

	if (elementos == 0){
		cout << "\n\tNenhum elemento cadastrado!" << endl;
	}
}

void ordenacao()
{
	string opcao = "";
	cout << "\tA - Ordenar por nome" <<endl;
    cout << "\tB - Ordenar por idade" <<endl;
    cout << "\tX - Voltar ao menu principal" <<endl;
    cout << "\n\t\tSua opção: ";
    cin >> opcao;

    if (opcao == "A" or opcao == "a"){
    	ordByName();
    }else if(opcao == "B" or opcao == "b"){
    	ordByIdade();
    }else if(opcao == "X" or opcao == "x"){
    	cout << "\n\tVoltando ao menu principal..." << endl;
    }else{
    	cout << "\n\tOpção inválida" << endl;
    	ordenacao();
    }
}

void ordByIdade() //Utiliza BubbleSort para ordenar
{
    for (int fim = QTD_OBJETO-1; fim > 0; --fim) {
        for (int i = 0; i < fim; ++i) {
        	if((objeto[i+1].id > 0) and (objeto[i+1].nome != "") and (objeto[i+1].idade > 0)){
	            if (objeto[i].idade > objeto[i+1].idade) {
	            	int auxId = objeto[i].id;
	            	string auxNome = objeto[i].nome;
	                int auxIdade = objeto[i].idade;

	                objeto[i].id = objeto[i+1].id;
	                objeto[i].nome = objeto[i+1].nome;
	                objeto[i].idade = objeto[i+1].idade;

	                objeto[i+1].id = auxId;
	                objeto[i+1].nome = auxNome;
	                objeto[i+1].idade = auxIdade;
	            }
	        }
        }
    }
}

void ordByName() //Utiliza BubbleSort para ordenar
{
    for (int fim = QTD_OBJETO-1; fim > 0; --fim) {
        for (int i = 0; i < fim; ++i) {
        	if((objeto[i+1].id > 0) and (objeto[i+1].nome != "") and (objeto[i+1].idade > 0)){
	            if (objeto[i].nome > objeto[i+1].nome) {
	            	int auxId = objeto[i].id;
	            	string auxNome = objeto[i].nome;
	                int auxIdade = objeto[i].idade;

	                objeto[i].id = objeto[i+1].id;
	                objeto[i].nome = objeto[i+1].nome;
	                objeto[i].idade = objeto[i+1].idade;

	                objeto[i+1].id = auxId;
	                objeto[i+1].nome = auxNome;
	                objeto[i+1].idade = auxIdade;
	            }
	        }
        }
    }
}

void ordById() //Utiliza BubbleSort para ordenar
{
    for (int fim = QTD_OBJETO-1; fim > 0; --fim) {
        for (int i = 0; i < fim; ++i) {
        	if((objeto[i+1].id > 0) and (objeto[i+1].nome != "") and (objeto[i+1].idade > 0)){
	            if (objeto[i].id > objeto[i+1].id) {
	            	int auxId = objeto[i].id;
	            	string auxNome = objeto[i].nome;
	                int auxIdade = objeto[i].idade;

	                objeto[i].id = objeto[i+1].id;
	                objeto[i].nome = objeto[i+1].nome;
	                objeto[i].idade = objeto[i+1].idade;

	                objeto[i+1].id = auxId;
	                objeto[i+1].nome = auxNome;
	                objeto[i+1].idade = auxIdade;
	            }
	        }
        }
    }
}

void busca()
{
	string opcao = "";
	cout << "\tA - Buscar por nome" <<endl;
    cout << "\tB - Buscar por idade" <<endl;
    cout << "\tC - Buscar por id" <<endl;
    cout << "\tX - Voltar ao menu principal" <<endl;
    cout << "\n\t\tSua opção: ";
    cin >> opcao;

    if (opcao == "A" or opcao == "a"){
    	search("nome");
    }else if(opcao == "B" or opcao == "b"){
    	search("idade");
    }else if(opcao == "C" or opcao == "c"){
    	search("id");
    }else if(opcao == "X" or opcao == "x"){
    	cout << "\n\tVoltando ao menu principal..." << endl;
    }else{
    	cout << "\n\tOpção inválida" << endl;
    	ordenacao();
    }
}

void search(string tipo)
{
	loadObjAuxWithObj();

	if(tipo == "nome"){
		ordByName();
	}else if(tipo == "idade"){
		ordByIdade();
	}else if(tipo == "id"){
		ordById();
	}

	int inf = 0;     // limite inferior (o primeiro índice de vetor em C é zero          )
	int sup = posProx-1; // limite superior (termina em um número a menos. 0 a 9 são 10 números)
	int meio;
	int flag = 0;
	int chaveInt = 0;
	string chaveString = "";

	cout << "\n\t\tOBSERVAÇÃO SERÁ RETORNADO O PRIMEIRO ELEMENTO ENCONTRADO NA TABELA!";
	cout << "\n\t\tValor que desejas buscar: ";
	if(tipo == "nome"){
		cin >> chaveString;
	}else{
		cin >> chaveInt;
	}
    
	while (inf <= sup){
		meio = (inf + sup)/2;
		if ((chaveString == objeto[meio].nome and tipo == "nome") or 
			(chaveInt == objeto[meio].idade and tipo == "idade") or 
			(chaveInt == objeto[meio].id and tipo == "id")){
			flag = 1;
			break;
		}
		if ((chaveString < objeto[meio].nome and tipo == "nome") or 
			(chaveInt < objeto[meio].idade and tipo == "idade") or 
			(chaveInt < objeto[meio].id and tipo == "id")){
			sup = meio-1;
		}
		else{
			inf = meio+1;
		}
	}

	if(flag == 1){
		cout << "\n\tId: " << objeto[meio].id;
		cout << "\n\tNome: " << objeto[meio].nome;
		cout << "\n\tIdade: " << objeto[meio].idade << endl << endl;
		posBusc = meio;
	}else{
		cout << "\n\tNenhum elemento encontrado! " << endl << endl;
		posBusc = -1;
	}

	loadObjWithAux();
}

void loadObjAuxWithObj()
{
	for (int i = 0; i < QTD_OBJETO; ++i){
		objetoAux[i].id = objeto[i].id;
		objetoAux[i].nome = objeto[i].nome;
		objetoAux[i].idade = objeto[i].idade;
	}
}

void loadObjWithAux()
{
	for (int i = 0; i < QTD_OBJETO; ++i){
		objeto[i].id = objetoAux[i].id;
		objeto[i].nome = objetoAux[i].nome;
		objeto[i].idade = objetoAux[i].idade;
	}
}

void remove()
{	
	cout << "\t--BUSQUE O ELEMENTO DESEJADO PELO ID PARA SER EXCLUÍDO--" <<endl;
	int opcao = 0;
	search("id");
	cout << "\t--Deseja excluir o elemento encontrado?--" <<endl;
	cout << "\t\t1 - Sim" <<endl;
	cout << "\t\t2 - Não" <<endl;
	cout << "\n\t\tSua opção: ";
	cin >> opcao;

	if(opcao == 1){
		objeto[posBusc].id = -1;
		objeto[posBusc].nome = "";
		objeto[posBusc].idade = -1;
		cout << "\n\tElemento deletado!\n\tVoltando ao menu principal..." << endl;
	}else{
		cout << "\n\tElemento não deletado!\n\tVoltando ao menu principal..." << endl;
	}
}

void salvaTabela()
{
	int elementos = 0;
	
	arq.open("lista-de-pessoas.txt", ios::out);
	if(! arq.good()) {
		cout << "FALHA NA ABERTURA DO ARQUIVO\n";
	}

	for (int i = 0; i < posProx; ++i){
		if((objeto[i].id > 0) and (objeto[i].nome != "") and (objeto[i].idade > 0)){
			arq << objeto[i].nome << " | " << objeto[i].id << " " << objeto[i].idade;
			elementos++;
		}
	}

	if (elementos == 0){
		cout << "\n\tNenhum elemento cadastrado!" << endl;
	}

	arq.close();
}