#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <iomanip>	//para usar setw
#include <string>


using namespace std;
#define BITS_MEMORIA (7)
#define TAMANHO_MEMORIA (pow(2,BITS_MEMORIA))	//7 bits = 128 tamanho de memoria, 8 bits = 256 tamanho de memoria
#define QTD_ACC_ARQS_IN (40) //quantidade de arquivos que o ligador suporta ligar

enum ComandosFlag{
   LA = 0,	//Load acumulador				//A = [op]
   SA,		//Store acumulador				//[op] = A
   AA,		//somar acumulador				//A = A + [op]
   SUB,		//subtrair acumulador			//A = A - [op]
   MUL,		//multiplicar acumulador		//A = A * [op]
   DIV,		//dividir acumulador			//A = A / [op]
   JMP,		//jump							//PC = op ;
   JEQ,		//jump igual					//if (A == 0) PC = op;
   JGT,		//jump maior					//if (A) > 0) PC = op;
   JLT,		//jump menor					//if (A < 0) PC = op;
   PW,		//print word					//Print [op]
   RW,		//read word						//Read [op]
   STOP,	//fim de execução				//Stop machine
   END,
   SPACE,
   GLOBAL,
   EXTERN
};

enum ComandosTipo{
	umCampo = 0,	//END,STOP
	doisCampo,		//ADD,SUB,LOAD,STORE,MUL,DIV.JMP.JEQ,JGT,JLT,PQ,RW ou um label de um jump e um stop
	tresCampo			//Quando tem label do jump, ou é declaracao de variavel
};

enum Err{
	variasDeclaracao,
	comandoNaoReconhecido,
	terceiraPalavraComoComando,
	tamanhoVariavelInvalido,
	variavelNaoDeclarada
};

enum SimboloTipo{
	label = 0,
	variavel
};

struct erro
{
	string explicacao;
	int endereco;
	Err indentificacaoErro;
};

struct simbolos
{
	SimboloTipo tipo;
	string palavra;
  int codArquivo;
	int endereco;	//endereco de onde foi encontrado o simbolo
	int enderecoGrav; //endereco onde deve ser gravado o valor
};

struct variaveis
{
	int tamanho;
	string palavra;
  ComandosFlag tipo;  //só é setado qd for SPACE, GLOBAL, EXTERN
  int codArquivo;
	int enderecoInicio;
	int enderecoFim;
};

struct instrucao
{
	string milemonico;	//nome da isntrucao
	int codigo;
  int codArquivo;
	ComandosTipo tipo;
	ComandosFlag comando;
};

fstream leitura;
ofstream escrita;

simbolos simbolo[int(TAMANHO_MEMORIA)];
instrucao instruc[int(TAMANHO_MEMORIA)];
variaveis var[int(TAMANHO_MEMORIA)];

erro erros[int(TAMANHO_MEMORIA)];

int interatorErr = 0;
int interatorSimbol = 0;
int interatorVar = 0;
int fimCodigo = 0;
int endInstruc = 0;

void loader(string *nomeArquivoIn, string nomeArquivoOut, int QuantidadeDeArquivos);
void symbolTableGeneretor(string nomeArquivo, int codArquivo);
void setComando(string one, string two, string three, int endereco, int codArquivo);
void setFlagAndCodComando(int endereco);
bool isComand(string comando);
string removeEspacoBranco(string linha);
void setErr(string explicacao, int endereco, Err tipo);
void setSimbol(SimboloTipo tipo, string palavra, int endereco, int codArquivo);
void setVar(int tamanho, string palavra, ComandosFlag tipo, int codArquivo);
void setEnderecoVariaveis();
void setEnderecoSimbolos();
bool verificaVariavel(string palavra, int endereco, int codArquivo);
string getEnd(int endereco);
void codeGeneretor(string nomeArquivo);
void cleanInstrucTable();
void getErrosVariaveis();

int main(int argc, char const *argv[])
{
   string nomeArquivoIn[int(QTD_ACC_ARQS_IN)];
   int qtdIn = 0;
   string nomeArquivoOut;

   if(argc >= 4 && argc <= (QTD_ACC_ARQS_IN+2)){

    for (size_t i = 0; i < argc-2; i++) {
      nomeArquivoIn[i] = argv[i+1];
      cout << "Nome do "<<to_string(i+1)<<"º arquivo a ser lido: " << nomeArquivoIn[i] << endl;
      qtdIn++;
    }
    nomeArquivoOut = argv[argc-1];
    cout << "Nome do arquivo a ser escrito: " << nomeArquivoOut << endl;

    loader(nomeArquivoIn, nomeArquivoOut, int(qtdIn));
   }else{
     cout << "Quantidade de paramentros isuficientes!"<< endl;
     cout << "\tMinimo de parametros esperados:" << endl;
     cout << "\t\tParam 1: Endereço/nome do arquivo que o ligador irá ler com o código assembly e ligar com o segundo" << endl;
     cout << "\t\tParam 2: Endereço/nome do arquivo que o ligador irá ler com o código assembly e ligar com o primeiro" << endl;
     cout << "\t\tParam 3: Endereço/nome do arquivo que o ligador irá salvar com o codigo decimal do assembly" << endl;
   }
   return 0;
}


void loader(string *nomeArquivoIn, string nomeArquivoOut, int QuantidadeDeArquivos)
{
  for (size_t i = 0; i < QuantidadeDeArquivos; i++) {
	   symbolTableGeneretor(nomeArquivoIn[i], i);
  }
  // for (size_t i = 0; i < TAMANHO_MEMORIA; i++) {
  //   std::cout << "milemonico: " << instruc[i].milemonico <<'\n';
  //   std::cout << "cod: " << instruc[i].codigo <<'\n';
  //   std::cout << "tipo: " << instruc[i].tipo <<'\n';
  //   std::cout << "comando: " << instruc[i].comando <<'\n';
  // }
	codeGeneretor(nomeArquivoOut);
}

void symbolTableGeneretor(string nomeArquivo, int codArquivo)
{
	int j = 0;
	string linha, one,two, three, aux;
  fimCodigo = 0;
  std::cout <<"Lendo "<< nomeArquivo << "..." << endl;
	leitura.open(nomeArquivo);
	while(getline (leitura, linha)){
			linha = removeEspacoBranco(linha);
			istringstream lineStream(linha);
			j = 0;
			one = "";
			two = "";
			three = "";
			while(!lineStream.eof()){
				getline(lineStream, aux, ' ');
				if( j == 0){
				 	one = aux;
				}else if( j == 1){
				 	two = aux;
				}else if( j == 2){
				 	three = aux;
				}
				j++;
			}

			if(one != "" and two == "" and three == ""){
				instruc[endInstruc].tipo = umCampo;
				instruc[endInstruc].milemonico = one;
			}else if(two != "" and three == ""){
				instruc[endInstruc].tipo = doisCampo;
			}else{
			 	instruc[endInstruc].tipo = tresCampo;
			}
			setComando(one,two,three,endInstruc, codArquivo);
			endInstruc++;
			if(fimCodigo != 0){
        leitura.close();
				break;
			}
	}
}

void setComando(string one, string two, string three, int endereco, int codArquivo)
{
	bool teste = true;
	if(instruc[endereco].tipo == umCampo){
		setFlagAndCodComando(endereco);
	}else{
		if(isComand(one)){
			instruc[endereco].milemonico = one;
			setFlagAndCodComando(endereco);

      if(instruc[endereco].comando == EXTERN){
        setVar(-1, two, instruc[endereco].comando, codArquivo);
      }else	if(two.compare("") != 0){
				setSimbol(variavel, two, endereco, codArquivo);
			}
		}else if(isComand(two)){
			instruc[endereco].milemonico = two;
			setFlagAndCodComando(endereco);

			if(instruc[endereco].comando == SPACE || instruc[endereco].comando == GLOBAL){
				if((atoi(three.c_str())/1)==atoi(three.c_str())){
					if((atoi(three.c_str()) >= 0) && (atoi(three.c_str()) <= int(TAMANHO_MEMORIA))){
						if(verificaVariavel(three, endereco, codArquivo) == true){
							setVar(atoi(three.c_str()), one, instruc[endereco].comando, codArquivo);
						}
					}else{
						setErr("O tamanho declarado para está variavel é maior que a memoria", endereco, tamanhoVariavelInvalido);
					}
				}else{
					setErr("O tamanho declarado para está variavel não é um numero", endereco, tamanhoVariavelInvalido);
				}
			}else{
				setSimbol(label, one, endereco, codArquivo);
				if(three.compare("") != 0){
					setSimbol(variavel, three, endereco, codArquivo);
				}
			}

		}else if(isComand(three)){
			setErr("O comando nesta linha esta sendo utilizado de forma errada, não pode haver um comando no final da linha!", endereco, terceiraPalavraComoComando);
		}
	}
	if(instruc[endereco].comando == END){
		fimCodigo = endereco;
	}
}

void setFlagAndCodComando(int endereco)
{
	if(instruc[endereco].milemonico == "LA"){
		instruc[endereco].comando = LA;
		instruc[endereco].codigo = 0;
	}else if(instruc[endereco].milemonico == "SA"){
		instruc[endereco].comando = SA;
		instruc[endereco].codigo = 1;
	}else if(instruc[endereco].milemonico == "AA"){
		instruc[endereco].comando = AA;
		instruc[endereco].codigo = 2;
	}else if(instruc[endereco].milemonico == "SUB"){
		instruc[endereco].comando = SUB;
		instruc[endereco].codigo = 5;
	}else if(instruc[endereco].milemonico == "MUL"){
		instruc[endereco].comando = MUL;
		instruc[endereco].codigo = 3;
	}else if(instruc[endereco].milemonico == "DIV"){
		instruc[endereco].comando = DIV;
		instruc[endereco].codigo = 4;
	}else if(instruc[endereco].milemonico == "JMP"){
		instruc[endereco].comando = JMP;
		instruc[endereco].codigo = 6;
	}else if(instruc[endereco].milemonico == "JEQ"){
		instruc[endereco].comando = JEQ;
		instruc[endereco].codigo = 7;
	}else if(instruc[endereco].milemonico == "JGT"){
		instruc[endereco].comando = JGT;
		instruc[endereco].codigo = 8;
	}else if(instruc[endereco].milemonico == "JLT"){
		instruc[endereco].comando = JLT;
		instruc[endereco].codigo = 9;
	}else if(instruc[endereco].milemonico == "PW"){
		instruc[endereco].comando = PW;
		instruc[endereco].codigo = 10;
	}else if(instruc[endereco].milemonico == "RW"){
		instruc[endereco].comando = RW;
		instruc[endereco].codigo = 11;
	}else if(instruc[endereco].milemonico == "STOP"){
		instruc[endereco].comando = STOP;
		instruc[endereco].codigo = 12;
	}else if(instruc[endereco].milemonico == "END"){
		instruc[endereco].comando = END;
    instruc[endereco].codigo = -1;
	}else if(instruc[endereco].milemonico == "SPACE"){
		instruc[endereco].comando = SPACE;
    instruc[endereco].codigo = -1;
  }else if(instruc[endereco].milemonico == "GLOBAL"){
		instruc[endereco].comando = GLOBAL;
    instruc[endereco].codigo = -1;
  }else if(instruc[endereco].milemonico == "EXTERN"){
		instruc[endereco].comando = EXTERN;
    instruc[endereco].codigo = -1;
	}else{
		setErr("O comando desta linha não é reconhecido pela linguagem utilizada", endereco, comandoNaoReconhecido);
	}
}

bool isComand(string comando)
{
	if(comando == "LA"){
		return true;
	}else if(comando == "SA"){
		return true;
	}else if(comando == "AA"){
		return true;
	}else if(comando == "SUB"){
		return true;
	}else if(comando == "MUL"){
		return true;
	}else if(comando == "DIV"){
		return true;
	}else if(comando == "JMP"){
		return true;
	}else if(comando == "JEQ"){
		return true;
	}else if(comando == "JGT"){
		return true;
	}else if(comando == "JLT"){
		return true;
	}else if(comando == "PW"){
		return true;
	}else if(comando == "RW"){
		return true;
	}else if(comando == "STOP"){
		return true;
	}else if(comando == "END"){
		return true;
	}else if(comando == "SPACE"){
		return true;
  }else if(comando == "GLOBAL"){
		return true;
  }else if(comando == "EXTERN"){
		return true;
	}else{
		return false;
	}
}

string removeEspacoBranco(string linha)
{
	string aux = "";
	string novaLinha = "";

	for (int i = 0; i < linha.size(); ++i)
	{
		if(linha[i] != ' ' and linha[i] != '	' and linha[i] != '\t'){
			aux = linha[i];
			novaLinha = novaLinha + aux;
		}else if(linha[i-1] != ' ' and linha[i-1] != '	' and linha[i-1] != '\t' and i > 0){
			aux = " ";
			novaLinha = novaLinha + aux;
		}
	}
	return novaLinha;
}

void setErr(string explicacao, int endereco, Err tipo)
{
	erros[interatorErr].explicacao = explicacao;
	erros[interatorErr].endereco = endereco;
	erros[interatorErr].indentificacaoErro = tipo;
	interatorErr++;
}

void setSimbol(SimboloTipo tipo, string palavra, int endereco, int codArquivo)
{
	simbolo[interatorSimbol].tipo = tipo;
	simbolo[interatorSimbol].palavra = palavra;
	simbolo[interatorSimbol].endereco = endereco;
  simbolo[interatorSimbol].codArquivo = codArquivo;
	simbolo[interatorSimbol].enderecoGrav = -1;
	interatorSimbol++;
}

void setVar(int tamanho, string palavra, ComandosFlag tipo, int codArquivo)
{
	var[interatorVar].tamanho = tamanho;
  var[interatorVar].tipo = tipo;
  var[interatorVar].codArquivo = codArquivo;
	var[interatorVar].palavra = palavra;
	interatorVar++;
}

void setEnderecoVariaveis()
{
	int enderecoVariaveis = fimCodigo+1;
  getErrosVariaveis();
	for (int i = 0; i <= interatorVar; ++i){
    if(var[i].tipo == SPACE || var[i].tipo == GLOBAL){
  		var[i].enderecoInicio = enderecoVariaveis;
  		enderecoVariaveis = enderecoVariaveis + var[i].tamanho;
  		var[i].enderecoFim = enderecoVariaveis;
  		//enderecoVariaveis++;
    }
	}
}

void setEnderecoSimbolos()
{
	for (int i = 0; i < fimCodigo; ++i){ //encontra e set os endereco das label dos jmp
		if(simbolo[i].tipo == label){
			for (int j = 0; j < fimCodigo; ++j){
				if(simbolo[j].tipo == variavel && simbolo[j].palavra.compare(simbolo[i].palavra) == 0){
					simbolo[j].enderecoGrav = simbolo[i].endereco;
				}
			}
		}
	}

	for (int i = 0; i < interatorSimbol; ++i){
		if(simbolo[i].tipo == variavel){
			for (int j = 0; j < interatorVar; ++j){
				if(var[j].palavra.compare(simbolo[i].palavra) == 0){
          if((var[j].tipo == SPACE && var[j].codArquivo == simbolo[i].codArquivo) || var[j].tipo != SPACE){
            simbolo[i].enderecoGrav = var[j].enderecoInicio;
  					break;
          }
				}
			}
		}
	}

	for (int i = 0; i < interatorSimbol; ++i){
		if(simbolo[i].tipo == variavel && simbolo[i].enderecoGrav < 0){
			setErr("A variavel não foi declarada", simbolo[i].endereco, variavelNaoDeclarada);
		}
	}
}

bool verificaVariavel(string palavra, int endereco, int codArquivo)
{
	bool teste = true;
	for (int i = 0; i < interatorVar; ++i){
		if(palavra.compare(var[i].palavra) == 0 && codArquivo == var[i].codArquivo){
			setErr("Está variavel já foi declarada", endereco,  variasDeclaracao);
			teste = false;
			break;
		}
	}
	return teste;
}

void escreveErr()
{
	cout << "\n\nCódigo com erros!\n\tLista de Erros:" << endl;
	for (int i = 0; i < interatorErr; ++i){
		cout << "\t\tEndereço:  " << to_string(erros[i].endereco) << endl;
		cout << "\t\t\t-Tipo:  " << erros[i].indentificacaoErro << endl;
		cout << "\t\t\t-Explicacao:  " << erros[i].explicacao << endl;
	}
}

string getEnd(int endereco)
{
	string texto;
	if(instruc[endereco].tipo == umCampo){
		texto = "00";
	}else{
		for (int i = 0; i < interatorSimbol; ++i){
			if(simbolo[i].endereco == endereco && simbolo[i].tipo == variavel){
				texto = to_string(simbolo[i].enderecoGrav);
				break;
			}
		}
	}

	return texto;
}

void cleanInstrucTable()  //remove todas as instruções de sistema SPACE, GLOBAL, EXTERN, END
{
  for (int i = 0; i <= fimCodigo; ++i){
    if (instruc[i].codigo == -1){
      for (size_t j = i; j <= fimCodigo; j++) {
        for (size_t k = 0; k <= interatorSimbol; k++) {
          if(simbolo[k].endereco == j){
            simbolo[k].endereco = j - 1;
            k = 0;
            continue;
          }
        }
        instruc[j].milemonico = instruc[j+1].milemonico;
        instruc[j].codigo = instruc[j+1].codigo;
        instruc[j].tipo = instruc[j+1].tipo;
        instruc[j].comando = instruc[j+1].comando;
      }
      fimCodigo--;
      cleanInstrucTable();
      break;
    }
  }
}

void getErrosVariaveis()
{
  for (size_t i = 0; i <= interatorVar; i++) {
    for (size_t j = 0; j <= interatorVar; j++) {
      if(var[i].tipo == EXTERN){
        if(var[i].palavra == var[j].palavra && var[j].tipo != GLOBAL && var[j].codArquivo != var[i].codArquivo){
          setErr("A variavel '"+var[i].palavra+"' não foi declarada como global em nenhum arquivo", -1, variavelNaoDeclarada);
        }
      }else if(var[i].tipo == GLOBAL){
        if(var[i].palavra == var[j].palavra && var[j].codArquivo != var[i].codArquivo && var[j].tipo == GLOBAL){
          setErr("A variavel '"+var[i].palavra+"' foi declarada como global em mais de um arquivo ("+ to_string(var[j].codArquivo)+","+to_string(var[i].codArquivo)+")", -1, variasDeclaracao);
        }
      }else if(var[i].palavra == var[j].palavra && var[j].codArquivo == var[i].codArquivo && i != j){
        setErr("A variavel '"+var[i].palavra+"' foi declarada mais de uma vez no arquivo ("+ to_string(var[j].codArquivo)+")", -1, variasDeclaracao);
      }
    }
  }
}

void codeGeneretor(string nomeArquivoOut)
{
	string aux;
  cleanInstrucTable();
  fimCodigo++;
	setEnderecoVariaveis();
	setEnderecoSimbolos();

	if(interatorErr == 0){

		escrita.open(nomeArquivoOut, ios::out);

		if(! escrita.good()) {
			cout << "FALHA NA ABERTURA DO ARQUIVO\n";
		}else{
			cout << "Gerando código" << endl;
			for (int i = 0; i < fimCodigo; ++i){
  			aux = getEnd(i);
  			escrita << instruc[i].codigo << " " << aux << endl;
			}
      cout << "Código gerado" << endl;
		}

		escrita.close();
	}else{
		escreveErr();
	}
}
