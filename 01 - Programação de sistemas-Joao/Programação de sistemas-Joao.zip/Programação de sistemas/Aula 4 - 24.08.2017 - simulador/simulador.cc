#include <iostream>
#include <fstream>
#include <string>
#include <math.h>

#include <chrono>	//para transformar em milliseconds
#include <thread>	//para pausar a thread atual

#include <iomanip>	//para usar setw

using namespace std;
#define BITS_MEMORIA (7)
#define TAMANHO_MEMORIA (pow(2,BITS_MEMORIA))	//7 bits = 128 tamanho de memoria, 8 bits = 256 tamanho de memoria

enum ComandosFlag{
   LA = 0,	//Load acumulador				//A = [op]
   SA,		//Store acumulador				//[op] = A
   AA,		//somar acumulador				//A = A + [op]
   SUB,		//subtrair acumulador			//A = A - [op]
   MUL,		//multiplicar acumulador		//A = A * [op]
   DIV,		//dividir acumulador			//A = A / [op]
   JMP,		//jump							//PC = op ;
   JEQ,		//jump igual					//if (A == 0) PC = op;
   JGT,		//jump maior					//if (A) > 0) PC = op;
   JLT,		//jump menor					//if (A < 0) PC = op;
   PW,		//print word					//Print [op]
   RW,		//read word						//Read [op]
   STOP,	//fim de execução				//Stop machine
   VAL		//caso não seja um comando fica indicando que é um valor que esta armazenado
};


struct memoria{
	int operador = 0;
	int operando = 0;
	ComandosFlag comando;
};

struct computador{
	int PC = 0;
	int AC = 0;
	int R0 = 0;
	int R1 = 0;
};

fstream leitura;
ofstream escrita;

memoria mem[int(TAMANHO_MEMORIA)];
computador comp;


void loader(string nomeArquivo);
void setFlagComando(int endereco);
string getFlagComando(int endereco);
void executeComand(int endereco);
void cpu(bool showStepByStep, bool slowed,int timeStop, bool clearWindow);
int showMemoria(bool comment);
int saveMemoria(bool comment,string nomeArquivoMemoria);

int main(int argc, char const *argv[])
{
	string nomeArquivoIn;
  string nomeArquivoOut;

  if(argc >= 3 ){
  	//cout << "Nome do arquivo a ser lido: ";
  	//cin >> nomeArquivo;
  	nomeArquivoIn = argv[1];
    cout << "Nome do arquivo a ser lido: " << nomeArquivoIn << endl;
  	loader(nomeArquivoIn);

  	//showMemoria(true);

  	cpu(false, false, 500, false);

  	//showMemoria(false);
    nomeArquivoOut = argv[2];
    cout << "Nome do arquivo a ser escrito: " << nomeArquivoOut << endl;
  	saveMemoria(true, nomeArquivoOut);
  }else{
    cout << "Quantidade de paramentros isuficientes!"<< endl;
    cout << "\tParametros esperados:" << endl;
    cout << "\t\tParam 1: Endereço/nome do arquivo que o simulador irá ler para simular" << endl;
    cout << "\t\tParam 2: Endereço/nome do arquivo que o simulador irá salvar a memória" << endl;
  }
	return 0;
}

void loader(string nomeArquivo)
{
	cout << "Entrou na função de loader..." << endl;
	int i = 0;
	leitura.open(nomeArquivo);
	while(leitura >> (mem[i].operador)){
		leitura >> mem[i].operando;
		setFlagComando(i);
		i++;
	}
	cout << "Sai da função de loader..." << endl;
}


void cpu(bool showStepByStep,bool slowed,int timeStop, bool clearWindow)
{
	cout << "Entrou na função de cpu..." << endl;
	do{
		if(clearWindow == true){
			system("clear");
		}
		if(slowed == true){
			std::this_thread::sleep_for(std::chrono::milliseconds(timeStop));
		}

		if(showStepByStep == true){
			cout << "PC: " << setw(3) <<  comp.PC << "\t\t|\tAC: " << setw(3) << comp.AC << "\t\t|\tR0: " << setw(3) << comp.R0 << "\t\t|\tR1: " << setw(3) << comp.R1<< endl;
			cout << getFlagComando(comp.PC) << "  " << mem[comp.PC].operando << endl;
		}

		executeComand(comp.PC);
  }while(mem[comp.PC].comando != STOP);
	cout << "Saiu da função de cpu..." << endl;
}

void setFlagComando(int endereco)
{
	switch(mem[endereco].operador){
		case 0:
		mem[endereco].comando = LA;				//poderia ser atribuido da mesma maneira com ComandosFlag(0)
		break;

		case 1:
		mem[endereco].comando = SA;
		break;

		case 2:
		mem[endereco].comando = AA;
		break;

		case 3:
		mem[endereco].comando = MUL;
		break;

		case 4:
		mem[endereco].comando = DIV;
		break;

		case 5:
		mem[endereco].comando = SUB;
		break;

		case 6:
		mem[endereco].comando = JMP;
		break;

		case 7:
		mem[endereco].comando = JEQ;
		break;

		case 8:
		mem[endereco].comando = JGT;
		break;

		case 9:
		mem[endereco].comando = JLT;
		break;

		case 10:
		mem[endereco].comando = PW;
		break;

		case 11:
		mem[endereco].comando = RW;
		break;

		case 12:
		mem[endereco].comando = STOP;
		break;

		default:		//caso o comando nao seja identificado, ele marca que é um valor para realizar operacos
		mem[endereco].comando = VAL;
		break;
	}
}

string getFlagComando(int endereco)
{
	switch(mem[endereco].comando){
		case LA:
		return "LOAD";
		break;

		case SA:
		return "STORE";
		break;

		case AA:
		return "ADD";
		break;

		case MUL:
		return "MUL";
		break;

		case DIV:
		return "DIV";
		break;

		case SUB:
		return "SUB";
		break;

		case JMP:
		return "JMP";
		break;

		case JEQ:
		return "JEQ";
		break;

		case JGT:
		return "JGT";
		break;

		case JLT:
		return "JLT";
		break;

		case PW:
		return "PW";
		break;

		case RW:
		return "RW";
		break;

		case STOP:
		return "STOP";
		break;

		default:	//caso seja um val ~~ valor para operacao
		return std::to_string(mem[endereco].operador);
		break;
	}
}

void executeComand(int endereco)
{
	switch(mem[endereco].comando){
		case LA:
		comp.AC = mem[mem[endereco].operando].operador;
		comp.PC++;
		break;

		case SA:
		mem[mem[endereco].operando].operador = comp.AC;
		comp.PC++;
		break;

		case AA:
		comp.AC += mem[mem[endereco].operando].operador;
		comp.PC++;
		break;

		case MUL:
		comp.AC *= mem[mem[endereco].operando].operador;
		comp.PC++;
		break;

		case DIV:
		comp.AC /= mem[mem[endereco].operando].operador;
		comp.PC++;
		break;

		case SUB:
		comp.AC -= mem[mem[endereco].operando].operador;
		comp.PC++;
		break;

		case JMP:
		comp.PC = mem[mem[endereco].operando].operador;
		comp.PC++;
		break;

		case JEQ:
		if(comp.AC == 0){
			comp.PC = mem[endereco].operando;
		}else{
			comp.PC++;
		}
		break;

		case JGT:
		if(comp.AC > 0){
			comp.PC = mem[endereco].operando;
		}else{
			comp.PC++;
		}
		break;

		case JLT:
		if(comp.AC < 0){
			comp.PC = mem[endereco].operando;
		}else{
			comp.PC++;
		}
		break;

		case PW:
    cout << "Valor de saida (endereço : " << to_string(mem[endereco].operando) << "):\t ";
		cout << to_string(mem[mem[endereco].operando].operador) << endl;
		comp.PC++;
		break;

		case RW:
    cout << "Entre com um valor (endereço : " << to_string(mem[endereco].operando) << "):\t ";
		cin >> mem[mem[endereco].operando].operador;
		comp.PC++;
		break;

		case STOP:
		break;

		default:	//caso seja um val ~~ valor para operacao
		cout << "Este dado não é um comando e sim um valor para operacao" << endl;
		break;
	}
}

int showMemoria(bool comment)
{
	cout << "Entrou na função de showMemoria..." << endl;
	if(comment){
		cout << setw(6) << "end: " << setw(6) << "\tcomand\t" << setw(6) << "end\t\t;" << setw(6) << "comand\t" << setw(6) << "end\t" << setw(6) << "valor do end" << endl;
		for (int i = 0; i < TAMANHO_MEMORIA; i++){
			cout << setw(6) << i << ": " << setw(6) << mem[i].operador << "\t" << setw(6) << mem[i].operando << "\t\t;" << setw(6) << getFlagComando(i) << "\t" << setw(6) << mem[i].operando << "\t" << setw(6) << mem[mem[i].operando].operador<< endl;
		}
	}else{
		for (int i = 0; i < TAMANHO_MEMORIA; i++){
			cout << setw(6) << i << ": " << setw(6) << mem[i].operador << "\t" << setw(6) << mem[i].operando << endl;
		}
	}
	cout << "saiu na função de showMemoria..." << endl;
	return 1;
}

int saveMemoria(bool comment, string nomeArquivoMemoria)
{
	int elementos = 0;
	escrita.open(nomeArquivoMemoria, ios::out);

	cout << "Entrou na função de saveMemoria..." << endl;

	if(! escrita.good()) {
		cout << "FALHA NA ABERTURA DO ARQUIVO\n";
	}else{
		if(comment){
			escrita << setw(6) << "\tcomand\t" << setw(6) << "end\t\t;" << setw(6) << "comand\t" << setw(6) << "end\t" << setw(6) << "valor do end" << endl;
			for (int i = 0; i < TAMANHO_MEMORIA; i++){
				escrita << setw(6) << mem[i].operador << "\t" << setw(6) << mem[i].operando << "\t\t;" << setw(6) << getFlagComando(i) << "\t" << setw(6) << mem[i].operando << "\t" << setw(6) << mem[mem[i].operando].operador<< endl;
				elementos++;
			}
		}else{
			for (int i = 0; i < TAMANHO_MEMORIA; i++){
				escrita << setw(6) << mem[i].operador << "    " << setw(6) << mem[i].operando << endl;
				elementos++;
			}
		}
	}

	if (elementos == 0){
		cout << "\n\tNenhum elemento cadastrado!" << endl;
	}

	escrita.close();
	cout << "Sai da função de saveMemoria..." << endl;
	return 1;
}
