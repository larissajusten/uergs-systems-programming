#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <iomanip>	//para usar setw
#include <string>


using namespace std;
#define BITS_MEMORIA (7)
#define TAMANHO_MEMORIA (pow(2,BITS_MEMORIA))	//7 bits = 128 tamanho de memoria, 8 bits = 256 tamanho de memoria

enum ComandosFlag{
   LA = 0,	//Load acumulador				//A = [op]
   SA,		//Store acumulador				//[op] = A
   AA,		//somar acumulador				//A = A + [op]
   SUB,		//subtrair acumulador			//A = A - [op]
   MUL,		//multiplicar acumulador		//A = A * [op]
   DIV,		//dividir acumulador			//A = A / [op]
   JMP,		//jump							//PC = op ;
   JEQ,		//jump igual					//if (A == 0) PC = op;
   JGT,		//jump maior					//if (A) > 0) PC = op;
   JLT,		//jump menor					//if (A < 0) PC = op;
   PW,		//print word					//Print [op]
   RW,		//read word						//Read [op]
   STOP,	//fim de execução				//Stop machine
   END,
   SPACE
};

enum ComandosTipo{
	umCampo = 0,	//END,STOP
	doisCampo,		//ADD,SUB,LOAD,STORE,MUL,DIV.JMP.JEQ,JGT,JLT,PQ,RW ou um label de um jump e um stop
	tresCampo			//Quando tem label do jump, ou é declaracao de variavel
};

enum Err{
	variasDeclaracao,
	comandoNaoReconhecido,
	terceiraPalavraComoComando,
	tamanhoVariavelInvalido,
	variavelNaoDeclarada
};

enum SimboloTipo{
	label = 0,
	variavel
};

struct erro
{
	string explicacao;
	int endereco;
	Err indentificacaoErro;
};

struct simbolos
{
	SimboloTipo tipo;
	string palavra;
	int endereco;	//endereco de onde foi encontrado o simbolo
	int enderecoGrav; //endereco onde deve ser gravado o valor
};

struct variaveis
{
	int tamanho;
	string palavra;
	int enderecoInicio;
	int enderecoFim;
};

struct instrucao
{
	string milemonico;	//nome da isntrucao
	int codigo;
	ComandosTipo tipo;
	ComandosFlag comando;
};

fstream leitura;
ofstream escrita;

simbolos simbolo[int(TAMANHO_MEMORIA)];
instrucao instruc[int(TAMANHO_MEMORIA)];
variaveis var[int(TAMANHO_MEMORIA)];

erro erros[int(TAMANHO_MEMORIA)];

int interatorErr = 0;
int interatorSimbol = 0;
int interatorVar = 0;
int fimCodigo = 0;

void loader(string nomeArquivoIn, string nomeArquivoOut);
void symbolTableGeneretor(string nomeArquivo);
void setComando(string one, string two, string three, int endereco);
void setFlagAndCodComando(int endereco);
bool isComand(string comando);
string removeEspacoBranco(string linha);
void setErr(string explicacao, int endereco, Err tipo);
void setSimbol(SimboloTipo tipo, string palavra, int endereco);
void setVar(int tamanho, string palavra);
void setEnderecoVariaveis();
void setEnderecoSimbolos();
bool verificaVariavel(string palavra, int endereco);
string getEnd(int endereco);
void codeGeneretor(string nomeArquivo);

int main(int argc, char const *argv[])
{
   string nomeArquivoIn;
   string nomeArquivoOut;

   if(argc >= 3 ){

   	nomeArquivoIn = argv[1];
    cout << "Nome do arquivo a ser lido: " << nomeArquivoIn << endl;
    nomeArquivoOut = argv[2];
    cout << "Nome do arquivo a ser escrito: " << nomeArquivoOut << endl;

    loader(nomeArquivoIn, nomeArquivoOut);
   }else{
     cout << "Quantidade de paramentros isuficientes!"<< endl;
     cout << "\tParametros esperados:" << endl;
     cout << "\t\tParam 1: Endereço/nome do arquivo que o montador irá ler com o código assembly" << endl;
     cout << "\t\tParam 2: Endereço/nome do arquivo que o montador irá salvar com o codigo decimal do assembly" << endl;
   }
   return 0;
}


void loader(string nomeArquivoIn, string nomeArquivoOut)
{
	symbolTableGeneretor(nomeArquivoIn);
	codeGeneretor(nomeArquivoOut);
}

void symbolTableGeneretor(string nomeArquivo)
{
	int i = 0, j = 0;
	string linha, one,two, three, aux;
	leitura.open(nomeArquivo);
	while(getline (leitura, linha)){
			linha = removeEspacoBranco(linha);
			istringstream lineStream(linha);
			j = 0;
			one = "";
			two = "";
			three = "";
			while(!lineStream.eof()){
				getline(lineStream, aux, ' ');
				if( j == 0){
				 	one = aux;
				}else if( j == 1){
				 	two = aux;
				}else if( j == 2){
				 	three = aux;
				}
				j++;
			}

			if(one != "" and two == "" and three == ""){
				instruc[i].tipo = umCampo;
				instruc[i].milemonico = one;
			}else if(two != "" and three == ""){
				instruc[i].tipo = doisCampo;
			}else{
			 	instruc[i].tipo = tresCampo;
			}
			setComando(one,two,three,i);
			i++;
			if(fimCodigo != 0){
				break;
			}
	}
}

void setComando(string one, string two, string three, int endereco)
{
	bool teste = true;
	if(instruc[endereco].tipo == umCampo){
		setFlagAndCodComando(endereco);
	}else{
		if(isComand(one)){
			instruc[endereco].milemonico = one;
			setFlagAndCodComando(endereco);
			if(two.compare("") != 0){
				setSimbol(variavel, two, endereco);
			}
		}else if(isComand(two)){
			instruc[endereco].milemonico = two;
			setFlagAndCodComando(endereco);

			if(instruc[endereco].comando == SPACE){
				if((atoi(three.c_str())/1)==atoi(three.c_str())){
					if((atoi(three.c_str()) >= 0) && (atoi(three.c_str()) <= int(TAMANHO_MEMORIA))){
						if(verificaVariavel(three, endereco) == true){
							setVar(atoi(three.c_str()), one);
						}
					}else{
						setErr("O tamanho declarado para está variavel é maior que a memoria", endereco, tamanhoVariavelInvalido);
					}
				}else{
					setErr("O tamanho declarado para está variavel não é um numero", endereco, tamanhoVariavelInvalido);
				}
			}else{
				setSimbol(label, one, endereco);
				if(three.compare("") != 0){
					setSimbol(variavel, three, endereco);
				}
			}

		}else if(isComand(three)){
			setErr("O comando nesta linha esta sendo utilizado de forma errada, não pode haver um comando no final da linha!", endereco, terceiraPalavraComoComando);
		}
	}
	if(instruc[endereco].comando == END){
		fimCodigo = endereco;
	}
}

void setFlagAndCodComando(int endereco)
{
	if(instruc[endereco].milemonico == "LA"){
		instruc[endereco].comando = LA;
		instruc[endereco].codigo = 0;
	}else if(instruc[endereco].milemonico == "SA"){
		instruc[endereco].comando = SA;
		instruc[endereco].codigo = 1;
	}else if(instruc[endereco].milemonico == "AA"){
		instruc[endereco].comando = AA;
		instruc[endereco].codigo = 2;
	}else if(instruc[endereco].milemonico == "SUB"){
		instruc[endereco].comando = SUB;
		instruc[endereco].codigo = 5;
	}else if(instruc[endereco].milemonico == "MUL"){
		instruc[endereco].comando = MUL;
		instruc[endereco].codigo = 3;
	}else if(instruc[endereco].milemonico == "DIV"){
		instruc[endereco].comando = DIV;
		instruc[endereco].codigo = 4;
	}else if(instruc[endereco].milemonico == "JMP"){
		instruc[endereco].comando = JMP;
		instruc[endereco].codigo = 6;
	}else if(instruc[endereco].milemonico == "JEQ"){
		instruc[endereco].comando = JEQ;
		instruc[endereco].codigo = 7;
	}else if(instruc[endereco].milemonico == "JGT"){
		instruc[endereco].comando = JGT;
		instruc[endereco].codigo = 8;
	}else if(instruc[endereco].milemonico == "JLT"){
		instruc[endereco].comando = JLT;
		instruc[endereco].codigo = 9;
	}else if(instruc[endereco].milemonico == "PW"){
		instruc[endereco].comando = PW;
		instruc[endereco].codigo = 10;
	}else if(instruc[endereco].milemonico == "RW"){
		instruc[endereco].comando = RW;
		instruc[endereco].codigo = 11;
	}else if(instruc[endereco].milemonico == "STOP"){
		instruc[endereco].comando = STOP;
		instruc[endereco].codigo = 12;
	}else if(instruc[endereco].milemonico == "END"){
		instruc[endereco].comando = END;
	}else if(instruc[endereco].milemonico == "SPACE"){
		instruc[endereco].comando = SPACE;
	}else{
		setErr("O comando desta linha não é reconhecido pela linguagem utilizada", endereco, comandoNaoReconhecido);
	}
}

bool isComand(string comando)
{
	if(comando == "LA"){
		return true;
	}else if(comando == "SA"){
		return true;
	}else if(comando == "AA"){
		return true;
	}else if(comando == "SUB"){
		return true;
	}else if(comando == "MUL"){
		return true;
	}else if(comando == "DIV"){
		return true;
	}else if(comando == "JMP"){
		return true;
	}else if(comando == "JEQ"){
		return true;
	}else if(comando == "JGT"){
		return true;
	}else if(comando == "JLT"){
		return true;
	}else if(comando == "PW"){
		return true;
	}else if(comando == "RW"){
		return true;
	}else if(comando == "STOP"){
		return true;
	}else if(comando == "END"){
		return true;
	}else if(comando == "SPACE"){
		return true;
	}else{
		return false;
	}
}

string removeEspacoBranco(string linha)
{
	string aux = "";
	string novaLinha = "";

	for (int i = 0; i < linha.size(); ++i)
	{
		if(linha[i] != ' ' and linha[i] != '	' and linha[i] != '\t'){
			aux = linha[i];
			novaLinha = novaLinha + aux;
		}else if(linha[i-1] != ' ' and linha[i-1] != '	' and linha[i-1] != '\t' and i > 0){
			aux = " ";
			novaLinha = novaLinha + aux;
		}
	}
	return novaLinha;
}

void setErr(string explicacao, int endereco, Err tipo)
{
	erros[interatorErr].explicacao = explicacao;
	erros[interatorErr].endereco = endereco;
	erros[interatorErr].indentificacaoErro = tipo;
	interatorErr++;
}

void setSimbol(SimboloTipo tipo, string palavra, int endereco)
{
	simbolo[interatorSimbol].tipo = tipo;
	simbolo[interatorSimbol].palavra = palavra;
	simbolo[interatorSimbol].endereco = endereco;
	simbolo[interatorSimbol].enderecoGrav = -1;
	interatorSimbol++;
}

void setVar(int tamanho, string palavra)
{
	var[interatorVar].tamanho = tamanho;
	var[interatorVar].palavra = palavra;
	interatorVar++;
}

void setEnderecoVariaveis()
{
	int enderecoVariaveis = fimCodigo+1;

	for (int i = 0; i <= interatorVar; ++i){
		var[i].enderecoInicio = enderecoVariaveis;
		enderecoVariaveis = enderecoVariaveis + var[i].tamanho;
		var[i].enderecoFim = enderecoVariaveis;
		//enderecoVariaveis++;
	}
}

void setEnderecoSimbolos()
{
	for (int i = 0; i < fimCodigo; ++i){ //encontra e set os endereco das label dos jmp
		if(simbolo[i].tipo == label){
			for (int j = 0; j < fimCodigo; ++j){
				if(simbolo[j].tipo == variavel && simbolo[j].palavra.compare(simbolo[i].palavra) == 0){
					simbolo[j].enderecoGrav = simbolo[i].endereco;
				}
			}
		}
	}

	for (int i = 0; i < interatorSimbol; ++i){
		if(simbolo[i].tipo == variavel){
			for (int j = 0; j < interatorVar; ++j){
				if(var[j].palavra.compare(simbolo[i].palavra) == 0){
					simbolo[i].enderecoGrav = var[j].enderecoInicio;
					break;
				}
			}
		}
	}

	for (int i = 0; i < interatorSimbol; ++i){
		if(simbolo[i].tipo == variavel && simbolo[i].enderecoGrav < 0){
			setErr("A variavel não foi declarada", simbolo[i].endereco, variavelNaoDeclarada);
		}
	}
}

bool verificaVariavel(string palavra, int endereco)
{
	bool teste = true;
	for (int i = 0; i < interatorVar; ++i){
		if(palavra.compare(var[i].palavra) == 0){
			setErr("Está variavel já foi declarada", endereco, variasDeclaracao);
			teste = false;
			break;
		}
	}
	return teste;
}

void escreveErr()
{
	cout << "\n\nCódigo com erros!\n\tLista de Erros:" << endl;
	for (int i = 0; i < interatorErr; ++i){
		cout << "\t\tEndereço:  " << to_string(erros[i].endereco) << endl;
		cout << "\t\t\t-Tipo:  " << erros[i].indentificacaoErro << endl;
		cout << "\t\t\t-Explicacao:  " << erros[i].explicacao << endl;
	}
}

string getEnd(int endereco)
{
	string texto;
	if(instruc[endereco].tipo == umCampo){
		texto = "00";
	}else{
		for (int i = 0; i < interatorSimbol; ++i){
			if(simbolo[i].endereco == endereco && simbolo[i].tipo == variavel){
				texto = to_string(simbolo[i].enderecoGrav);
				break;
			}
		}
	}

	return texto;
}

void codeGeneretor(string nomeArquivoOut)
{
	string aux;
	setEnderecoVariaveis();
	setEnderecoSimbolos();

	if(interatorErr == 0){

		escrita.open(nomeArquivoOut, ios::out);

		if(! escrita.good()) {
			cout << "FALHA NA ABERTURA DO ARQUIVO\n";
		}else{
			cout << "Gerando código" << endl;
			for (int i = 0; i < fimCodigo; ++i){
				if(instruc[i].comando == SPACE){
					cout << "Código gerado" << endl;
					break;
				}else{
					aux = getEnd(i);
					escrita << instruc[i].codigo << " " << aux << endl;
				}
			}
		}

		escrita.close();
	}else{
		escreveErr();
	}
}
